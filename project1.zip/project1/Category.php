<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/project.css">
    <link rel="stylesheet" href="CSS/Result.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <script>
		function login(){
			window.open("Login-form.php")
			window.close()
		}
        function Home_page(){
            window.open("project.php")
            window.close()
        }
        function NewProducts(){
            window.open("NewProducts.php")
            window.close()
        }
        function predict(){
            window.open("predict.php")
            window.close()
        }
	</script>
    <title>Result</title>
</head>
<body>
    <center>
        <div id="tab">
            <input type="button" value="صفحه اصلی" id="btn-tab" onclick="Home_page()">
			<input type="button" value="جدیدترین محصولات" id="btn-tab" onclick="NewProducts()">
			<input type="button" value="پیشبینی" id="btn-tab" onclick="predict()">
			<input type="button" value="تماس با ما" id="btn-tab">
			<input type="button" value="درباره ما" id="btn-tab">
			<input type="button" value="ورود / ثبت نام" id="btn-tab" onclick="login()" method="block">
		</div>
        <div id="hdr-Result">دسته بندی محصولات</div>
        <div id="Games"></div>
        <div id="Games"></div>
        <div id="Games"></div>
        <div id="Games"></div>
        <div id="Games"></div>
        <div id="Games"></div>
    </center>
</body>
</html>