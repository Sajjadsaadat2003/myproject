<?php session_start(); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css">
<title>نمایش اطلاعات</title>
</head>
<body>
<div class="container">
<p class="title_profile">پروفایل من</p>

<?php

// نام سرور، نام کاربری، رمز عبور و نام پایگاه داده دریافت میکند
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Sportball_DB";

// ساخت یک شئ PDO
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// تنظیم حالت خطاهای PDO روی استثناها
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// آماده کردن دستور SQL
$userID = $_SESSION['login'];
$stmt = $conn->prepare("SELECT * FROM `users` WHERE id = $userID;");

// اجرای دستور SQL
try {
  $stmt->execute();

  // بررسی اینکه آیا پستی در پایگاه داده وجود دارد یا خیر
  if ($stmt->rowCount() > 0) {
    // مرور پست ها و نمایش آنها
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo '<table id="customers" border="3">';
      if ($row['U_image'] == NULL) {
        echo '<tr><th colspan="2" style="width:100px"><center><input type="image" src="http://localhost/project1/pics/Sajjad.bmp" alt="تصویر کاربر" style="width:150px; height:120px;"></center></th></tr>';
      }else {
        echo '<tr><th colspan="2" style="width:100px"><center><input type="image" src="http://localhost/project1/pics/' . $row['U_image'] . '" alt="تصویر کاربر" style="width:150px; height:120px;"></center></th></tr>';
      }
      echo '<tr><th style="width:100px">نام کاربری :</th><th style="width:150px">' . $row['U_username'] . '</th></tr>';
      echo '<tr><th style="width:100px">ایمیل :</th><th style="width:150px">' . $row['U_email'] . '</th></tr>';
      echo '<tr><th style="width:100px">شماره همراه :</th><th style="width:150px">' . $row['U_tel'] . '</th></tr>';
      echo '</table>';
    }
  } else {
    // اگر کابری وجود نداشت به صفحه لاگین هدایت شو
    header("location: http://localhost/project1/registeration/login.php");
  }
} catch (PDOException $e) {
  // هر گونه خطا را مدیریت میکند
  echo $e->getMessage();
} finally {
  // خروج از اتصال PDO
  $conn = null;
}
?>
<center>
    <button type="submit" class="editProfile" onclick="window.open('http://localhost/project1/users/editProfile.php'); window.close();">ویرایش اطلاعات</button>
  <button type="submit" class="backTosite" onclick="window.open('http://localhost/project1/project.php'); window.close();">بازگشت به سایت</button><br>
  <a href="http://localhost/project1/process/logout.php" class="link-signin" style="text-align:center;">خروج از حساب کاربری</a>
</center>
</div>


</body>
</html>