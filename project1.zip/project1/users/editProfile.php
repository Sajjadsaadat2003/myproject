<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>ویرایش اطلاعات</title>
</head>
<body style="text-align:center;">
    <div class='main' align="center">
        <h1>ویرایش تصویر</h1>
        <?php
            if (isset($_GET['editPic']) and $_GET['editPic']==0) {
                echo "<p style='color:red;'> خطا در ویرایش تصویر</p>";
            } elseif (isset($_GET['editPic']) and $_GET['editPic']==1) {
                echo "<p style='color:lawngreen;'>با موفقیت ثبت شد</p>";
            }
        ?>
        <form action="http://localhost/project1/process/funcUsers.php" method="post">
            <input type="file" name="profilePic" id="profilePic" accept="image/*" placeholder="تصویر پروفایل خود را وارد کنید">
            <button type="submit" name="updateUserPic">ویرایش</button>
        </form>
    </div><br>
    <div class="main" align="center">
        <h1>ویرایش نام کاربری، ایمیل و شماره همراه</h1>
        <?php
            if (isset($_GET['editProfile']) and $_GET['editProfile']==0) {
                echo "<p style='color:red;'> خطا در ویرایش اطلاعات</p>";
            } elseif (isset($_GET['editProfile']) and $_GET['editProfile']==1) {
                echo "<p style='color:lawngreen;'>با موفقیت ثبت شد</p>";
            }
        ?>
        <form action="http://localhost/project1/process/funcUsers.php" method="post">
            <input type="text" name="username" class="up_input" placeholder="نام کاربری جدید را وارد کنید">
            <input type="text" name="U_email" class="up_input" placeholder="ایمیل جدید را وارد کنید">
            <input type="text" name="U_tel" class="up_input" placeholder="شماره همراه جدید را وارد کنید">
            <button type="submit" name="updateUserProfile">ویرایش</button>
        </form>
    </div><br>
    <div class="main" align="center">
        <h1>ویرایش رمزعبور</h1>
        <?php
            if (isset($_GET['editPass']) and $_GET['editPass']==0) {
                echo "<p style='color:red;'> خطا در ویرایش رمزعبور</p>";
            } elseif (isset($_GET['editPass']) and $_GET['editPass']==1) {
                echo "<p style='color:lawngreen;'>با موفقیت ثبت شد</p>";
            }
        ?>
        <form action="http://localhost/project1/process/funcUsers.php" method="post">
            <input type="password" name="U_passwordOld" class="up_input" placeholder="رمزعبور قدیم را وارد کنید" required>
            <input type="password" name="U_password" class="up_input" placeholder="رمز عبور جدید را وارد کنید">
            <input type="password" name="U_Rpassword" class="up_input" placeholder="تکرار رمز عبور را وارد کنید">
            <button type="submit" name="updateUserPass">ویرایش</button>
        </form>
    </div>
    
    <button type="submit" class="cancel" name="cancel" onclick="window.open('http://localhost/project1/users/Profile.php'); window.close();">بازگشت</button>
</body>
</html>