function NewProducts(){
    window.open("NewProducts.php")
    window.close()
}
function Clock_page(){
    window.open("Clock-page.php")
}
function Predict(){
    window.open("Predict.php")
    window.close()
}
function Category(){
    window.open("Category.php")
    window.close()
}