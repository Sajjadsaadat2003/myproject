function TeamAGoals(n) {
    var Goals = document.getElementById("TeamA-Goal").value;
    if (n==1) {
        if (Goals==0) {
            document.getElementById("TeamA-Goal").value=1;
        }else if (Goals==1) {
            document.getElementById("TeamA-Goal").value=2;
        }else if (Goals==2) {
            document.getElementById("TeamA-Goal").value=3;
        }else if (Goals==3) {
            document.getElementById("TeamA-Goal").value=4;
        }else if (Goals==4) {
            document.getElementById("TeamA-Goal").value=5;
        }else if (Goals==5) {
            document.getElementById("TeamA-Goal").value=6;
        }else if (Goals==6) {
            document.getElementById("TeamA-Goal").value=7;
        }else if (Goals==7) {
            document.getElementById("TeamA-Goal").value=8;
        }else if (Goals==8) {
            document.getElementById("TeamA-Goal").value=9;
        }else if (Goals==9) {
            document.getElementById("TeamA-Goal").value=10;
        }
    } else if (n==-1) {
        if (Goals==10) {
            document.getElementById("TeamA-Goal").value=9;
        } else if (Goals==9) {
            document.getElementById("TeamA-Goal").value=8;
        } else if (Goals==8) {
            document.getElementById("TeamA-Goal").value=7;
        } else if (Goals==7) {
            document.getElementById("TeamA-Goal").value=6;
        } else if (Goals==6) {
            document.getElementById("TeamA-Goal").value=5;
        } else if (Goals==5) {
            document.getElementById("TeamA-Goal").value=4;
        } else if (Goals==4) {
            document.getElementById("TeamA-Goal").value=3;
        } else if (Goals==3) {
            document.getElementById("TeamA-Goal").value=2;
        } else if (Goals==2) {
            document.getElementById("TeamA-Goal").value=1;
        } else if (Goals==1) {
            document.getElementById("TeamA-Goal").value=0;
        }
    } 
}
function TeamBGoals(n) {
    var Goals = document.getElementById("TeamB-Goal").value;
    if (n==1) {
        if (Goals==0) {
            document.getElementById("TeamB-Goal").value=1;
        }else if (Goals==1) {
            document.getElementById("TeamB-Goal").value=2;
        }else if (Goals==2) {
            document.getElementById("TeamB-Goal").value=3;
        }else if (Goals==3) {
            document.getElementById("TeamB-Goal").value=4;
        }else if (Goals==4) {
            document.getElementById("TeamB-Goal").value=5;
        }else if (Goals==5) {
            document.getElementById("TeamB-Goal").value=6;
        }else if (Goals==6) {
            document.getElementById("TeamB-Goal").value=7;
        }else if (Goals==7) {
            document.getElementById("TeamB-Goal").value=8;
        }else if (Goals==8) {
            document.getElementById("TeamB-Goal").value=9;
        }else if (Goals==9) {
            document.getElementById("TeamB-Goal").value=10;
        }
    } else if (n==-1) {
        if (Goals==10) {
            document.getElementById("TeamB-Goal").value=9;
        } else if (Goals==9) {
            document.getElementById("TeamB-Goal").value=8;
        } else if (Goals==8) {
            document.getElementById("TeamB-Goal").value=7;
        } else if (Goals==7) {
            document.getElementById("TeamB-Goal").value=6;
        } else if (Goals==6) {
            document.getElementById("TeamB-Goal").value=5;
        } else if (Goals==5) {
            document.getElementById("TeamB-Goal").value=4;
        } else if (Goals==4) {
            document.getElementById("TeamB-Goal").value=3;
        } else if (Goals==3) {
            document.getElementById("TeamB-Goal").value=2;
        } else if (Goals==2) {
            document.getElementById("TeamB-Goal").value=1;
        } else if (Goals==1) {
            document.getElementById("TeamB-Goal").value=0;
        }
    } 
}
function Submit(){
    document.getElementById("Aprev").style.display = "none";
    document.getElementById("Anext").style.display = "none";
    document.getElementById("Bprev").style.display = "none";
    document.getElementById("Bnext").style.display = "none";
    document.getElementById("VS").style.marginLeft = "60px";
    document.getElementById("TeamA-Goal").style.marginLeft = "50px";
    document.getElementById("TeamB-Goal").style.marginRight = "50px";
}