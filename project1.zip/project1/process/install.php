<?php
include 'database.php';

// نام سرور، نام کاربری، رمز عبور و نام پایگاه داده دریافت میکند
$dsn = 'mysql:host=localhost;dbname=Sportball_DB';
$username = 'root';
$password = '';

// ساخت یک شئ PDO
$pdo = new PDO($dsn, $username, $password);

// تنظیم حالت خطاهای PDO روی استثناها
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

///ایجاد جدول کاربران///
try {
    $sql = 'CREATE TABLE users (
        id INT NOT NULL AUTO_INCREMENT,
        U_username VARCHAR(100) NOT NULL,
        U_email VARCHAR(255) NOT NULL,
        U_tel VARCHAR(11) NOT NULL,
        U_password VARCHAR(255) NOT NULL,
        U_Rpassword VARCHAR(255) NOT NULL,
        U_image BLOB,
        PRIMARY KEY (id)
        );';
    $pdo->exec($sql);
} catch (PDOException $e) {
    echo '- خطا در ساخت جدول کاربران -';
}
