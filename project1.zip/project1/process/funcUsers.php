<?php
session_start();
include 'install.php';

///بررسی ارسال فرم///
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ///اگر فرم ویرایش تصویر ارسال شد دستورات مربوط به ان را اجرا کن///
    if (isset($_POST['profilePic']) and !empty($_POST['profilePic'])) {
        if (editPic($_POST['profilePic'])) {
            header("location: http://localhost/project1/users/editProfile.php?editPic=1");
            exit;
        } else {
            header("location: http://localhost/project1/users/editProfile.php?editPic=0");
            exit;
        }
    }
    ///اگر فرم ویرایش اطلاعات ارسال شد دستورات مربوط به ان را اجرا کن///
    if (isset($_POST['username']) and isset($_POST['U_email']) and isset($_POST['U_tel'])) {
        if (!empty($_POST['username']) and !empty($_POST['U_email']) and !empty($_POST['U_tel'])) {
            if (editProfile($_POST['username'], $_POST['U_email'], $_POST['U_tel'])) {
                header("location: http://localhost/project1/users/editProfile.php?editProfile=1");
                exit;
            } else {
                header("location: http://localhost/project1/users/editProfile.php?editProfile=0");
                exit;
            }
        }
    }
    ///اگر فرم ویرایش پسورد ارسال شد دستورات مربوط به ان را اجرا کن///
    if (isset($_POST['U_passwordOld']) and isset($_POST['U_password']) and isset($_POST['U_Rpassword'])) {
        if (!empty($_POST['U_passwordOld']) and !empty($_POST['U_password']) and !empty($_POST['U_Rpassword'])) {
            if (editPass($_POST['U_passwordOld'], $_POST['U_password'], $_POST['U_Rpassword'])) {
                header("location: http://localhost/project1/users/editProfile.php?editPass=1");
                exit;
            } else {
                header("location: http://localhost/project1/users/editProfile.php?editPass=0");
                exit;
            }
        }
    }
}

////تابع ویرایش تصویر کاربر////
function editPic($profilePic)
{
    global $pdo;
    $id = $_SESSION['login'];
    $sql = "UPDATE users SET U_image = :profilePic  WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([ ':profilePic' => $profilePic, ':id' => $id]);
    return $stmt->rowCount();
}

////تابع ویرایش اطلاعات کاربر////
function editProfile($profileUsername, $profileEmail, $profileTel)
{
    global $pdo;
    $id = $_SESSION['login'];
    $sql = "UPDATE users SET U_username = :profileUsername, U_email = :profileEmail, U_tel = :profileTel  WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([ ':profileUsername' => $profileUsername, ':profileEmail' => $profileEmail, ':profileTel' => $profileTel, ':id' => $id]);
    return $stmt->rowCount();
}

//////بررسی صحت پسورد و تکرارش///////
function checkpassword($password, $Rpassword)
{
    if ($password == $Rpassword) {
        if (empty($password)) 
		{
			return false;
			}else{
			if(preg_match("/^(?=.*[A-z])(?=.*[0-9])(?=.*[$@])\S{6,12}$/", $password))
			{
				return true;
			}else{
				return false;
			} 
		}
    }else {
        return false;
    }
}

////بررسی پسورد برای اپدیت کردن اطلاعات////
function checkPasswordOld($passwordOld)
{
    global $pdo;
    $sql = "SELECT * FROM users WHERE U_password = :password";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':password' => md5($passwordOld)]);
    return $stmt->rowCount();
}

////تابع ویرایش پسورد کاربر////
function editPass($passwordOld, $password, $Rpassword)
{
    global $pdo;
    if (!checkPasswordOld($passwordOld)) {
        return false;
    }elseif (!checkpassword($password, $Rpassword)) {
        return false;
    }else{
        $id = $_SESSION['login'];
        $sql = "UPDATE users SET U_password = :password, U_Rpassword = :Rpassword WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([ ':password' => md5($password), ':Rpassword' => md5($Rpassword), ':id' => $id]);
        return $stmt->rowCount();
    }
}