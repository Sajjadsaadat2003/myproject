<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sportball</title>
    <link rel="stylesheet" href="CSS/project.css">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<script src="js/Click.js"></script>
</head>
<body>
	<div id="MyClockDisplay" class="clock" onload="showTime()"></div>
	<div class="siteName"><a href="project.php" id="linkLogo">Sportball</a></div>
	<br><br><br>
	<center>
	<marquee scrollamount="5" direction="right">
		.این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد
	</marquee>	
	<div id="tab">
		<input type="button" value="محصولات جدید" id="btn-tab" onclick="NewProducts()">
		<input type="button" value="دسته ها" id="btn-tab" onclick="Category()">
		<input type="button" value="پیشبینی" id="btn-tab" onclick="Predict()">
		<input type="button" value="تماس با ما" id="btn-tab">
		<input type="button" value="درباره ما" id="btn-tab">
		<?php if (!isset($_SESSION['login'])) : ?>
			<input type="button" value="ورود / ثبت نام" id="btn-tab" onclick="window.open('registeration/Login.php')">
		<?php else : ?>
			<input type="button" value="پروفایل" id="btn-tab" onclick="window.open('http://localhost/project1/users/profile.php')">
		<?php endif; ?>
	</div>
	<div id="baner">
		<div id="bnr-l">
			<div id="bnr-space"></div>
			<div id="img-op-l">
				<label id="lbl-titr">به نام خدا</label><br>
				<label id="lbl-text">
					این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد. این یک متن برای تست می باشد
				</label>
			</div>
		</div>
		<div id="bnr-r">
			<div id="bnr-rb">
				<div class="mySlides fade">
					<div class="academyit2">•<f id="•">••</f></div>
					<img src="pics/logoname.png">
				</div>
				<div class="mySlides fade">
					<div class="academyit2"><f id="•">•</f>•<f id="•">•</f></div>
					<img src="pics/car8.jpg">
				</div>
				<div class="mySlides fade">
					<div class="academyit2"><f id="•">••</f>•</div>
					<img src="pics/car5.jpg">
				</div>
				<a class="prev" onclick="plusSlides(-1)">&#10092;</a>
				<a class="next" onclick="plusSlides(1)">&#10093;</a>
			</div>
			<div id="slides">
				<h3>محبوب ترین دسته ها</h3>
				<ul class="MyList">
					<li><a href="#">دسته شماره 1</a></li>
					<li><a href="#">دسته شماره 2</a></li>
					<li><a href="#">دسته شماره 3</a></li>
					<li><a href="#">دسته شماره 4</a></li>
				</ul>
			</div>
		</div>
	</div>
	</center>
	<script src="js/Clock.js"></script>
	<script src="js/Slide.js"></script>
</body>
</html>