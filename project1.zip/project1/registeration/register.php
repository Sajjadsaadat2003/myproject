<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت نام</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="http://localhost/project1/favicon.ico" type="image/x-icon">
</head>
<body>
<?php if (isset($_SESSION['login'])) : ?>
    <?php header("location: http://localhost/project1/users/profile.php"); ?>
        <?php else : ?>
            <div class='main'>
                <h1>ثبت نام</h1>
                <hr>
                <?php
                    if (isset($_GET['reegister'])) {
                        echo "<p id='errorLogin'> خطا در ثبت نام ! (ممکن است نام کاربری از قبل موجود باشد یا رمزعبور از فرمت صحیح پیروی نمیکند)</p>";
                    } else {
                        echo " ";
                    }
                ?>
                <form action="http://localhost/project1/process/functions.php" method="post">
                    <p>: نام کاربری</p>
                    <input type="text" name="username" minlength="3" placeholder="نام کاربری خود را وارد کنید" required>
                    <p>: ایمیل</p>
                    <input type="email" name="U_email" placeholder="ایمیل خود را وارد کنید" required>
                    <p>: شماره همراه</p>
                    <input type="text" name="U_tel" minlength="11" maxlength="11" placeholder="شماره همراه خود را وارد کنید" required>
                    <p>: رمز عبور</p>
                    <input type="password" name="U_password" minlength="8" placeholder="رمز عبور خود را وارد کنید" required>
                    <p>: تکرار رمز عبور</p>
                    <input type="password" name="U_Rpassword" placeholder="تکرار رمز عبور خود را وارد کنید" required>
                    <p>: جواب سوال زیر را بنویسید</p>
                    <?php 
                        $A=rand(1,50);
                        $B=rand(1,50);
                        $C=$A+$B;
                        echo("<p align='left'>" . $A . " + " . $B . "= ?</p>");
                    ?>
                    <input type="text" name="U_CAPCHA" placeholder="جواب سوال بالا" required>
                    <button type="submit" name="register">ثبت</button>
                    <a href="login.php" class="link-signin">حساب کاربری دارید؟ وارد شوید</a>
                </form>
            </div>
        <?php endif; ?>
</body>
</html>