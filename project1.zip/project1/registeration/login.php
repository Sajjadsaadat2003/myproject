<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="http://localhost/project1/favicon.ico" type="image/x-icon">
</head>
<body>
<?php if (isset($_SESSION['login'])) : ?>
    <?php header("location: http://localhost/project1/project.php"); ?>
    <?php else : ?>
        <div class='main'>
            <h1>وارد شوید</h1>
            <hr>
            <?php
            if (isset($_GET['id'])) {
                echo "<p id='errorLogin'> ! نام کاربری یا رمزعبور اشتباه است </p>";
            } else {
                echo " ";
            }
            ?>
            <form action="http://localhost/project1/process/functions.php" method="post">
                <p>: نام کاربری</p>
                <input type="text" name="username" placeholder="نام کاربری خود را وارد کنید" required>
                <p>: رمز عبور</p>
                <input type="password" name="U_password" placeholder="رمز عبور خود را وارد کنید" required>
                <button type="submit" name="login">ورود</button>
                <a href="register.php" class="link-signin">حساب کاربری ندارید؟ ثبت نام کنید</a>
            </form>
        </div>
    <?php endif; ?>
</body>
</html>